package com.example.aluno_uffs.myapplication;

public class Jogo {
    String nomeJogo;
    double valorJogo;

    public double getValorJogo() {
        return valorJogo;
    }

    public String getNomeJogo() {
        return nomeJogo;
    }

    public void setNomeJogo(String nomeJogo) {
        this.nomeJogo = nomeJogo;
    }

    public void setValorJogo(double valorJogo) {
        this.valorJogo = valorJogo;
    }
}
