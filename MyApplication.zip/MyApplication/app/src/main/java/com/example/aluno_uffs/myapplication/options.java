package com.example.aluno_uffs.myapplication;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;


public class options extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.optionsactivity);
    }
}
