import java.util.ArrayList;
import java.util.Scanner;

public class Blog{
  public static void main(String[] args){
    private ArrayList<Post> posts = new ArrayList<>();
    Scanner teclado = new Scanner();
    String t, b, c, s;
    int l=0, d=0, st;
    Date dt;

    public void showAll(){
      for(int i = 0; i < posts.size(); i++){
          Post p = posts.get(i);
  				p.show();
        }
    }

    public void readData(Post p){
      System.out.println("Digite o título:\n");
      t = teclado.nextLine();
      p.setTitle(t);
      System.out.println("Digite o conteúdo:\n");
      c = teclado.nextLine();
      p.setContent(c);
      if(p = instanceOf(News)){
        System.out.println("Digite a fonte:\n");
        s = teclado.nextLine();
        p.setSource(s);
      }else if(p = instanceOf(ProductReview)){
        System.out.println("Digite a marca:\n");
        b = teclado.nextLine();
        p.setBrand();
        System.out.println("Digite quantas estrelas para essa resenha:\n");
        st = teclado.nextInt();
        p.setStars();
      }
      posts.add(p);
    }

    int n;
    do{
      System.out.println("BLOG: o que voce quer fazer? \n");
      System.out.println("1: Adicionar um novo post: \n");
      System.out.println("4: Listar todas as postagens: \n");
      System.out.println("5: Curtir uma postagem:\n");
      System.out.println("6: Não curtir uma postagem: \n");
      System.out.println("10: Sair\n");
      System.out.println("Escolha a opção: ");

      n = teclado.nextInt();
      switch(n){
        case 1:
          System.out.println("Escolha o tipo do post: \n");
          System.out.println("1: Post de noticia \n");
          System.out.println("2: nova de resenha de produtos:\n");
          System.out.println("3: Post de outros assuntos: \n");
          n = teclado.nextInt();
          if(n = 3){
            Post p = new Post();
            readData(p);
          }else if(n = 1){
            Post n = new News();
            readData(n);
          }else{
            Post p = new ProductReview();
            readData(p);
          }
          break;
        case 4:
          showAll();
          break;
        case 5:
          int h;
          System.out.println("Digite o indice do Post:\n");
          h = teclado.nextInt();
          Post p = posts.get(h);
          p.like();
          break;
        case 6:
          int h;
          System.out.println("Digite o indice do Post:\n");
          h = teclado.nextInt();
          Post p = posts.get(h);
          p.dislike();
          break;
        }
        case default:
          System.out.println("Opção inválida");
          break;
      }while(n != 10);

    }
  }
}
