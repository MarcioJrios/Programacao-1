public class ProductReview extends Post implements Evaluable{
  private String brand;
  private int stars;

  public ProductReview(String t, String c, int l, int d, String b, int s){
    super(t, c, l, d);
    this.brand = b;
  //  this.evaluate(st);  função da interface Evaluable
  }

  public ProductReview(){}

  public String getBrand(){
    return this.brand;
  }
  public void setBrand(String b){
    this.brand = b;
  }

  public int getStars(){
    return this.stars;
  }
  public void setStars(int st){
    this.stars = st;
  }

  @Override
  public void evaluate(int value){
    this.stars = value;
  }

  @Override
  public void show(){
    super.show();
    System.out.println("Marca: "+this.getBrand()+"\nEstrelas: "+this.getStars()+"\n");
  }

}
