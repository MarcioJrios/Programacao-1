public class ProductReview extends Post implements Evaluable{
  private String brand;
  private int stars;

  public ProductReview(String t, Date dt, String c, int l, int d, String b, int, s){
    super.ProductReview(String t, Date dt, String c, int l, int d);
    this.brand = b;
    this.evaluate(st);
  }

  public String getBrand(){
    return this.brand;
  }
  public void setBrand(String b){
    this.brand = b;
  }

  @Override
  public void evaluate(int value){
    this.stars = value;
  }

  public void show(){
    super.show();
    System.out.println("Marca: "+this.getBrand()+"\nEstrelas: "+this.getStars()+"\n");
  }
}
