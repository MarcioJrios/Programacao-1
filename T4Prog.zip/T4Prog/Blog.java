import java.util.ArrayList;
import java.util.Scanner;

public class Blog{
  public static void main(String[] args){
    private ArrayList<Post> posts = new ArrayList<>();
    Scanner teclado = new Scanner();
    String t, b, c, s;
    int l=0, d=0, st;
    Date dt;

    public void showAll(){

    }

    public void readData(Post p){

    }

    int n;
    do{
      System.out.println("BLOG: o que voce quer fazer? \n");
      System.out.println("1: Adicionar um novo post: \n");
      System.out.println("4: Listar todas as postagens: \n");
      System.out.println("5: Curtir uma postagem:\n");
      System.out.println("6: Não curtir uma postagem: \n");
      System.out.println("10: Sair\n");
      System.out.println("Escolha a opção: ");

      n = teclado.nextInt();
      switch(n){
        case 1:
          System.out.println("Escolha o tipo do post: \n");
          System.out.println("1: Post de noticia \n");
          System.out.println("2: nova de resenha de produtos:\n");
          System.out.println("3: Post de outros assuntos: \n");
          n = teclado.nextInt();
          if(n = 3){
            System.out.println("Digite o titulo do post:\n")
            t = teclado.nextLine();
            System.out.println("Digite a data:\n");
            System.out.println("Digite o conteudo do post:\n");
            c = teclado.nextLine();
            Post p = new Post(t, dt, c, l, d);
            posts.add(p);
          }else if(n = 1){
            System.out.println("Digite o titulo do post:\n")
            t = teclado.nextLine();
            System.out.println("Digite a data:\n");
            System.out.println("Digite o conteudo do post:\n");
            c = teclado.nextLine();
            System.out.println("Digite a fonte:\n");
            s = teclado.nextLine();
            News n = new News(t, dt, c, l, d, s);
            posts.add(n)
          }else {
            System.out.println("Digite o titulo do post:\n")
            t = teclado.nextLine();
            System.out.println("Digite a data:\n");
            System.out.println("Digite o conteudo do post:\n");
            c = teclado.nextLine();
            System.out.println("Digite a marca:\n");
            b = teclado.nextLine();
            System.out.println("Digite quantas estrelas para essa resenha:\n ");
            st = teclado.nextInt();

            ProductReview p = new ProductReview(t, dt, c, l, d, b, st);
            posts.add(p);
          }

        case 3:

        }

      }while(n != 10);

    }
  }
}
