import java.util.*;


public class Blog{
  public static void main(String[] args){
    ArrayList<Post> posts = new ArrayList<>();
    Scanner teclado = new Scanner(System.in);
    String t, b, c, s;
    int l=0, d=0, st;
    //Date dt;
    int n, h;
    Post p;

    do{
      System.out.println("BLOG: o que voce quer fazer? \n");
      System.out.println("1: Adicionar um novo post: \n");
      System.out.println("4: Listar todas as postagens: \n");
      System.out.println("5: Curtir uma postagem:\n");
      System.out.println("6: Não curtir uma postagem: \n");
      System.out.println("10: Sair\n");
      System.out.println("Escolha a opção: ");

      n = teclado.nextInt();
      switch(n){
        case 1:
          System.out.println("Escolha o tipo do post: \n");
          System.out.println("1: Post de noticia \n");
          System.out.println("2: nova de resenha de produtos:\n");
          System.out.println("3: Post de outros assuntos: \n");
          n = teclado.nextInt();
          if(n == 3){
            p = new Post();
            readData(p, posts);
          }else if(n == 1){
            p = new News();
            readData(p, posts);
          }else{
            p = new ProductReview();
            readData(p, posts);
          }
          break;
        case 4:
          showAll(posts);
          break;
        case 5:
          System.out.println("Digite o indice do Post:\n");
          h = teclado.nextInt();
          p = posts.get(h+1);
          p.like();
          break;
        case 6:
          System.out.println("Digite o indice do Post:\n");
          h = teclado.nextInt();
          p = posts.get(h+1);
          p.dislike();
          break;
        case 10:
          break;
        default:
          System.out.println("Opção inválida");
        }
      }while(n != 10);
}
public static void showAll(ArrayList<Post> posts){
  Post pst;
  for(int i = 0; i < posts.size(); i++){
      pst =  posts.get(i);
      pst.show();
  }
}

public static void readData(Post p, ArrayList<Post> pst){
  Scanner teclado = new Scanner(System.in);
  String t, b, c, s;
  int l, d, st;
  System.out.println("Digite o título:\n");
  t = teclado.nextLine();
  p.setTitle(t);
  System.out.println("Digite o conteúdo:\n");
  c = teclado.nextLine();
  p.setContent(c);
  p.setLikes();
  p.setDislikes();
  if(p instanceof News){
    News aux = (News)p;
    System.out.println("Digite a fonte:\n");
    s = teclado.nextLine();
    aux.setSource(s);
    pst.add(aux);
  }else if(p instanceof ProductReview){
    ProductReview aux = (ProductReview)p;
    System.out.println("Digite a marca:\n");
    b = teclado.nextLine();
    aux.setBrand(b);
    System.out.println("Digite quantas estrelas para essa resenha:\n");
    st = teclado.nextInt();
    aux.evaluate(st);
    pst.add(aux);
  } else
      pst.add(p);
    }
}
