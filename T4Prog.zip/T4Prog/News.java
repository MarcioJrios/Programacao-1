public class News extends Post{
  private String source;

  public News(String t, Date dt, String c, int l, int d, String s){
    super.News(String t, Date dt, String c, int l, int d);
    this.source = s;
  }

  public String getSource(){
    return this.source;
  }
  public void setSource(String s){
    this.source = s;
  }

  @Override
  public void show(){
    super.show();
    System.out.println("Fonte: "+this.getSource()+"\n");
  }
}
