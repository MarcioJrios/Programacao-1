public class News extends Post{
  private String source;

  public News(String t, String c, int l, int d, String s){
    super(t, c, l, d);
    this.source = s;
  }

  public News(){}

  public String getSource(){
    return this.source;
  }
  public void setSource(String s){
    this.source = s;
  }

  @Override
  public void show(){
    super.show();
    System.out.println("Fonte: "+this.getSource()+"\n");
  }
}
