public interface Evaluable{
  public void evaluate(int value);
}
