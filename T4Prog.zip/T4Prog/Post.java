public class Post{
  private String title;
  private Date date;
  private String content;
  private int likes;
  private int dislikes;

  public Post(String t, Date dt, String c, int l, int d){
    this.title = t;
    this.date = dt;
    this.content = c;
    this.likes = l;
    this.dislikes = d;
  }
  public String getTitle(){
    return this.title;
  }
  public void setTitle(String t){
    this.title = t;
  }

  public Date getDate(){
    return this.date;
  }
  public void setDate(Date d){
    this.date = d;
  }

  public String getContent(){
    return this.content;
  }
  public void setContent(String c){
    this.content = c;
  }

  public int getLikes(){
    return this.likes;
  }
  public void setLikes(int l){
    this.likes = l;
  }

  public int getDislikes(){
    return this.dislikes;
  }
  public void setDislikes(int d){
    this.dislikes = d;
  }
  public void show(){
    System.out.println("\nTitulo: "+this.getTitle()+"\nData: "+this.getDate()+"\nConteúdo: "+this.getContent()+"\nLikes: "+this.getLikes()+"\nDislikes: "+this.getDislikes()"\n");
  }

  public void like(){

  }

  public void dislike(){

  }

}
